/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Controller.h
 *
 * Code generated for Simulink model 'Controller'.
 *
 * Model version                  : 1.16
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Wed Jan 22 13:36:13 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Apple->ARM64
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef Controller_h_
#define Controller_h_
#ifndef Controller_COMMON_INCLUDES_
#define Controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "math.h"
#endif                                 /* Controller_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  real_T Delay_DSTATE[2];              /* '<S4>/Delay' */
  real_T Switch;                       /* '<S7>/Switch' */
  real_T FilterCoefficient;            /* '<S47>/Filter Coefficient' */
  real_T Switch_n;                     /* '<S4>/Switch' */
  real_T Driver_Control_Lamp;          /* '<S4>/Stateflow logic' */
  uint8_T is_active_c1_Controller;     /* '<S4>/Stateflow logic' */
  uint8_T is_c1_Controller;            /* '<S4>/Stateflow logic' */
  uint8_T temporalCounter_i1;          /* '<S4>/Stateflow logic' */
} DW;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S44>/Integrator' */
  real_T Filter_CSTATE;                /* '<S39>/Filter' */
} X;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S44>/Integrator' */
  real_T Filter_CSTATE;                /* '<S39>/Filter' */
} XDot;

/* State disabled  */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<S44>/Integrator' */
  boolean_T Filter_CSTATE;             /* '<S39>/Filter' */
} XDis;

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
typedef struct {
  real_T *f[1];                        /* derivatives */
} ODE1_IntgData;

#endif

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T Longitudinalvelocity;         /* '<Root>/Longitudinal velocity' */
  real_T ay;                           /* '<Root>/Lateral acceleration' */
  real_T Curvature;                    /* '<Root>/Curvature' */
  real_T CurvatureDerivative;          /* '<Root>/Curvature Derivative' */
  real_T relativeheadingangle;         /* '<Root>/relative_heading_angle' */
  real_T Lateraloffset;                /* '<Root>/Lateral_offset' */
  uint16_T LaneDetection;              /* '<Root>/Lane Detections' */
} ExtU;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T Throttle;                     /* '<Root>/Throttle' */
  real_T Brake;                        /* '<Root>/Brake' */
  real_T Steering_Angle;               /* '<Root>/Steering_Angle' */
} ExtY;

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][2];
  ODE1_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tStart;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Continuous states (default storage) */
extern X rtX;

/* Disabled states (default storage) */
extern XDis rtXDis;

/* Block signals and states (default storage) */
extern DW rtDW;

/* External inputs (root inport signals with default storage) */
extern ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY rtY;

/* Model entry point functions */
extern void Controller_initialize(void);
extern void Controller_step(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Add' : Unused code path elimination
 * Block '<S1>/Constant1' : Unused code path elimination
 * Block '<S7>/Scope' : Unused code path elimination
 * Block '<S7>/Scope1' : Unused code path elimination
 * Block '<S41>/Integral Gain' : Eliminated nontunable gain of 1
 * Block '<S51>/Saturation' : Eliminated Saturate block
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('LKA/Controller')    - opens subsystem LKA/Controller
 * hilite_system('LKA/Controller/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'LKA'
 * '<S1>'   : 'LKA/Controller'
 * '<S2>'   : 'LKA/Controller/LKA Controller'
 * '<S3>'   : 'LKA/Controller/Predictive Control'
 * '<S4>'   : 'LKA/Controller/LKA Controller/LKA mode logic'
 * '<S5>'   : 'LKA/Controller/LKA Controller/Stanley Controller'
 * '<S6>'   : 'LKA/Controller/LKA Controller/LKA mode logic/Stateflow logic'
 * '<S7>'   : 'LKA/Controller/Predictive Control/Brake Prediction Control'
 * '<S8>'   : 'LKA/Controller/Predictive Control/futureCurvature'
 * '<S9>'   : 'LKA/Controller/Predictive Control/Brake Prediction Control/MATLAB Function1'
 * '<S10>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller'
 * '<S11>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Anti-windup'
 * '<S12>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/D Gain'
 * '<S13>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/External Derivative'
 * '<S14>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Filter'
 * '<S15>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Filter ICs'
 * '<S16>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/I Gain'
 * '<S17>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Ideal P Gain'
 * '<S18>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Ideal P Gain Fdbk'
 * '<S19>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Integrator'
 * '<S20>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Integrator ICs'
 * '<S21>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/N Copy'
 * '<S22>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/N Gain'
 * '<S23>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/P Copy'
 * '<S24>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Parallel P Gain'
 * '<S25>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Reset Signal'
 * '<S26>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Saturation'
 * '<S27>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Saturation Fdbk'
 * '<S28>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Sum'
 * '<S29>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Sum Fdbk'
 * '<S30>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tracking Mode'
 * '<S31>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tracking Mode Sum'
 * '<S32>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tsamp - Integral'
 * '<S33>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tsamp - Ngain'
 * '<S34>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/postSat Signal'
 * '<S35>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/preSat Signal'
 * '<S36>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Anti-windup/Passthrough'
 * '<S37>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/D Gain/Internal Parameters'
 * '<S38>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/External Derivative/Error'
 * '<S39>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Filter/Cont. Filter'
 * '<S40>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Filter ICs/Internal IC - Filter'
 * '<S41>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/I Gain/Internal Parameters'
 * '<S42>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Ideal P Gain/Passthrough'
 * '<S43>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S44>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Integrator/Continuous'
 * '<S45>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Integrator ICs/Internal IC'
 * '<S46>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/N Copy/Disabled'
 * '<S47>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/N Gain/Internal Parameters'
 * '<S48>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/P Copy/Disabled'
 * '<S49>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Parallel P Gain/Internal Parameters'
 * '<S50>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Reset Signal/Disabled'
 * '<S51>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Saturation/Enabled'
 * '<S52>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Saturation Fdbk/Disabled'
 * '<S53>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Sum/Sum_PID'
 * '<S54>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Sum Fdbk/Disabled'
 * '<S55>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tracking Mode/Disabled'
 * '<S56>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S57>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tsamp - Integral/TsSignalSpecification'
 * '<S58>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/Tsamp - Ngain/Passthrough'
 * '<S59>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/postSat Signal/Forward_Path'
 * '<S60>'  : 'LKA/Controller/Predictive Control/Brake Prediction Control/PID Controller/preSat Signal/Forward_Path'
 */
#endif                                 /* Controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
