/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Controller.c
 *
 * Code generated for Simulink model 'Controller'.
 *
 * Model version                  : 1.16
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Wed Jan 22 13:36:13 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Apple->ARM64
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "Controller.h"
#include "rtwtypes.h"
#include <math.h>
#include "math.h"

/* Named constants for Chart: '<S4>/Stateflow logic' */
#define IN_Driver_control              ((uint8_T)1U)
#define IN_LKA_Initating               ((uint8_T)2U)
#define IN_LKA_active                  ((uint8_T)3U)
#define IN_Lane_Departure_warning      ((uint8_T)4U)

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

/* Continuous states */
X rtX;

/* Disabled State Vector */
XDis rtXDis;

/* Block signals and states (default storage) */
DW rtDW;

/* External inputs (root inport signals with default storage) */
ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
ExtY rtY;

/* Real-time model */
static RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;
extern real_T rt_atan2d_snf(real_T u0, real_T u1);

/* private model entry point functions */
extern void Controller_derivatives(void);
static real_T rtGetNaN(void);
static real32_T rtGetNaNF(void);

/*===========*
 * Constants *
 *===========*/
#define RT_PI                          3.14159265358979323846
#define RT_PIF                         3.1415927F
#define RT_LN_10                       2.30258509299404568402
#define RT_LN_10F                      2.3025851F
#define RT_LOG10E                      0.43429448190325182765
#define RT_LOG10EF                     0.43429449F
#define RT_E                           2.7182818284590452354
#define RT_EF                          2.7182817F

/*
 * UNUSED_PARAMETER(x)
 *   Used to specify that a function parameter (argument) is required but not
 *   accessed by the function body.
 */
#ifndef UNUSED_PARAMETER
#if defined(__LCC__)
#define UNUSED_PARAMETER(x)                                      /* do nothing */
#else

/*
 * This is the semi-ANSI standard way of indicating that an
 * unused function parameter is required.
 */
#define UNUSED_PARAMETER(x)            (void) (x)
#endif
#endif

extern real_T rtInf;
extern real_T rtMinusInf;
extern real_T rtNaN;
extern real32_T rtInfF;
extern real32_T rtMinusInfF;
extern real32_T rtNaNF;
static boolean_T rtIsInf(real_T value);
static boolean_T rtIsInfF(real32_T value);
static boolean_T rtIsNaN(real_T value);
static boolean_T rtIsNaNF(real32_T value);
real_T rtNaN = -(real_T)NAN;
real_T rtInf = (real_T)INFINITY;
real_T rtMinusInf = -(real_T)INFINITY;
real32_T rtNaNF = -(real32_T)NAN;
real32_T rtInfF = (real32_T)INFINITY;
real32_T rtMinusInfF = -(real32_T)INFINITY;

/* Return rtNaN needed by the generated code. */
static real_T rtGetNaN(void)
{
  return rtNaN;
}

/* Return rtNaNF needed by the generated code. */
static real32_T rtGetNaNF(void)
{
  return rtNaNF;
}

/* Test if value is infinite */
static boolean_T rtIsInf(real_T value)
{
  return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
}

/* Test if single-precision value is infinite */
static boolean_T rtIsInfF(real32_T value)
{
  return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
}

/* Test if value is not a number */
static boolean_T rtIsNaN(real_T value)
{
  return (boolean_T)(isnan(value) != 0);
}

/* Test if single-precision value is not a number */
static boolean_T rtIsNaNF(real32_T value)
{
  return (boolean_T)(isnan(value) != 0);
}

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  Controller_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    int32_T tmp;
    int32_T tmp_0;
    if (u0 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u1 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = atan2(tmp, tmp_0);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

/* Model step function */
void Controller_step(void)
{
  real_T rtb_Sum;
  real_T steer_expect;
  if (rtmIsMajorTimeStep(rtM)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&rtM->solverInfo,((rtM->Timing.clockTick0+1)*
      rtM->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(rtM)) {
    rtM->Timing.t[0] = rtsiGetT(&rtM->solverInfo);
  }

  if (rtmIsMajorTimeStep(rtM)) {
    /* Chart: '<S4>/Stateflow logic' incorporates:
     *  Constant: '<S4>/Length of car'
     *  Inport: '<Root>/Lane Detections'
     *  Inport: '<Root>/Lateral_offset'
     *  Inport: '<Root>/relative_heading_angle'
     */
    if (rtDW.temporalCounter_i1 < 15U) {
      rtDW.temporalCounter_i1++;
    }

    if (rtDW.is_active_c1_Controller == 0U) {
      rtDW.is_active_c1_Controller = 1U;
      rtDW.is_c1_Controller = IN_Driver_control;
      rtDW.Driver_Control_Lamp = 1.0;
    } else {
      switch (rtDW.is_c1_Controller) {
       case IN_Driver_control:
        rtDW.Driver_Control_Lamp = 1.0;
        if (rtU.LaneDetection == 1) {
          rtDW.is_c1_Controller = IN_LKA_Initating;
        }
        break;

       case IN_LKA_Initating:
        rtDW.Driver_Control_Lamp = 1.0;
        if (rtU.LaneDetection == 0) {
          rtDW.is_c1_Controller = IN_Driver_control;
        } else {
          steer_expect = 3.7 * sin(rtU.relativeheadingangle) + rtU.Lateraloffset;
          if (steer_expect < 1.8) {
            rtDW.is_c1_Controller = IN_LKA_active;
            rtDW.Driver_Control_Lamp = 0.0;
          } else if ((steer_expect > 1.8) && ((rtU.Lateraloffset < 0.0) ||
                      (rtU.Lateraloffset > 0.0) || (rtU.Lateraloffset == 0.0)))
          {
            rtDW.temporalCounter_i1 = 0U;
            rtDW.is_c1_Controller = IN_Lane_Departure_warning;
          }
        }
        break;

       case IN_LKA_active:
        rtDW.Driver_Control_Lamp = 0.0;
        if (rtU.LaneDetection == 0) {
          rtDW.is_c1_Controller = IN_Driver_control;
          rtDW.Driver_Control_Lamp = 1.0;
        } else if ((fabs(rtDW.Delay_DSTATE[0U]) > 1.5) && ((rtU.Lateraloffset <
                     0.0) || (rtU.Lateraloffset > 0.0) || (rtU.Lateraloffset ==
                     0.0))) {
          rtDW.temporalCounter_i1 = 0U;
          rtDW.is_c1_Controller = IN_Lane_Departure_warning;
          rtDW.Driver_Control_Lamp = 1.0;
        }
        break;

       default:
        /* case IN_Lane_Departure_warning: */
        rtDW.Driver_Control_Lamp = 1.0;
        if (rtDW.temporalCounter_i1 >= 12U) {
          rtDW.is_c1_Controller = IN_LKA_Initating;
        }
        break;
      }
    }

    /* End of Chart: '<S4>/Stateflow logic' */
  }

  /* MATLAB Function: '<S2>/Stanley Controller' incorporates:
   *  Inport: '<Root>/Lateral_offset'
   *  Inport: '<Root>/Longitudinal velocity'
   *  Inport: '<Root>/relative_heading_angle'
   */
  steer_expect = rtU.relativeheadingangle;
  if (rtU.relativeheadingangle > 3.1415926535897931) {
    while (steer_expect > 3.1415926535897931) {
      steer_expect -= 6.2831853071795862;
    }
  } else {
    while (steer_expect < 3.1415926535897931) {
      steer_expect += 6.2831853071795862;
    }
  }

  steer_expect += rt_atan2d_snf(3.0 * rtU.Lateraloffset,
    rtU.Longitudinalvelocity + 0.01);
  if (steer_expect > 3.1415926535897931) {
    while (steer_expect > 3.1415926535897931) {
      steer_expect -= 6.2831853071795862;
    }
  } else {
    while (steer_expect < 3.1415926535897931) {
      steer_expect += 6.2831853071795862;
    }
  }

  /* Switch: '<S4>/Switch2' incorporates:
   *  Constant: '<S4>/Manual Steering'
   *  MATLAB Function: '<S2>/Stanley Controller'
   */
  if (rtDW.Driver_Control_Lamp > 0.0) {
    steer_expect = 0.0;
  } else {
    steer_expect = fmax(-1.22, fmin(1.22, steer_expect));
  }

  /* End of Switch: '<S4>/Switch2' */

  /* Switch: '<S7>/Switch' incorporates:
   *  Inport: '<Root>/Lane Detections'
   */
  if (rtU.LaneDetection > 0) {
    /* Switch: '<S7>/Switch' incorporates:
     *  Gain: '<S8>/Gain'
     *  Inport: '<Root>/Curvature'
     *  Inport: '<Root>/Curvature Derivative'
     *  Inport: '<Root>/Longitudinal velocity'
     *  MATLAB Function: '<S7>/MATLAB Function1'
     *  Product: '<S8>/Product'
     *  Sum: '<S8>/Add'
     */
    rtDW.Switch = atan((rtU.CurvatureDerivative * rtU.Longitudinalvelocity * 2.0
                        + rtU.Curvature) * 2.8) - steer_expect;
  } else {
    /* Switch: '<S7>/Switch' incorporates:
     *  Constant: '<S7>/Zero'
     */
    rtDW.Switch = 0.0;
  }

  /* End of Switch: '<S7>/Switch' */

  /* Gain: '<S47>/Filter Coefficient' incorporates:
   *  Gain: '<S37>/Derivative Gain'
   *  Integrator: '<S39>/Filter'
   *  Sum: '<S39>/SumD'
   */
  rtDW.FilterCoefficient = (0.0 * rtDW.Switch - rtX.Filter_CSTATE) * 100.0;

  /* Sum: '<S53>/Sum' incorporates:
   *  Gain: '<S49>/Proportional Gain'
   *  Integrator: '<S44>/Integrator'
   */
  rtb_Sum = (1.1 * rtDW.Switch + rtX.Integrator_CSTATE) + rtDW.FilterCoefficient;

  /* Saturate: '<S7>/Saturation1' */
  if (rtb_Sum >= 0.0) {
    /* Outport: '<Root>/Throttle' incorporates:
     *  UnaryMinus: '<S7>/Unary Minus'
     */
    rtY.Throttle = -0.0;
  } else {
    /* Outport: '<Root>/Throttle' incorporates:
     *  UnaryMinus: '<S7>/Unary Minus'
     */
    rtY.Throttle = -rtb_Sum;
  }

  /* End of Saturate: '<S7>/Saturation1' */
  if (rtmIsMajorTimeStep(rtM)) {
    /* Switch: '<S4>/Switch' incorporates:
     *  Constant: '<S4>/Constant1'
     */
    rtDW.Switch_n = 0.0;
  }

  /* Saturate: '<S7>/Saturation' */
  if (rtb_Sum <= 0.0) {
    rtb_Sum = 0.0;
  }

  /* Outport: '<Root>/Brake' incorporates:
   *  Saturate: '<S7>/Saturation'
   *  Sum: '<S1>/Add1'
   */
  rtY.Brake = rtDW.Switch_n + rtb_Sum;

  /* Outport: '<Root>/Steering_Angle' */
  rtY.Steering_Angle = steer_expect;
  if (rtmIsMajorTimeStep(rtM)) {
    if (rtmIsMajorTimeStep(rtM)) {
      /* Update for Delay: '<S4>/Delay' incorporates:
       *  Inport: '<Root>/Lateral acceleration'
       */
      rtDW.Delay_DSTATE[0] = rtDW.Delay_DSTATE[1];
      rtDW.Delay_DSTATE[1] = rtU.ay;
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(rtM)) {
    rt_ertODEUpdateContinuousStates(&rtM->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     */
    ++rtM->Timing.clockTick0;
    rtM->Timing.t[0] = rtsiGetSolverStopTime(&rtM->solverInfo);

    {
      /* Update absolute timer for sample time: [0.1s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.1, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       */
      rtM->Timing.clockTick1++;
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void Controller_derivatives(void)
{
  XDot *_rtXdot;
  _rtXdot = ((XDot *) rtM->derivs);

  /* Derivatives for Integrator: '<S44>/Integrator' */
  _rtXdot->Integrator_CSTATE = rtDW.Switch;

  /* Derivatives for Integrator: '<S39>/Filter' */
  _rtXdot->Filter_CSTATE = rtDW.FilterCoefficient;
}

/* Model initialize function */
void Controller_initialize(void)
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&rtM->solverInfo, &rtM->Timing.simTimeStep);
    rtsiSetTPtr(&rtM->solverInfo, &rtmGetTPtr(rtM));
    rtsiSetStepSizePtr(&rtM->solverInfo, &rtM->Timing.stepSize0);
    rtsiSetdXPtr(&rtM->solverInfo, &rtM->derivs);
    rtsiSetContStatesPtr(&rtM->solverInfo, (real_T **) &rtM->contStates);
    rtsiSetNumContStatesPtr(&rtM->solverInfo, &rtM->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&rtM->solverInfo,
      &rtM->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&rtM->solverInfo,
      &rtM->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&rtM->solverInfo,
      &rtM->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&rtM->solverInfo, (boolean_T**)
      &rtM->contStateDisabled);
    rtsiSetErrorStatusPtr(&rtM->solverInfo, (&rtmGetErrorStatus(rtM)));
    rtsiSetRTModelPtr(&rtM->solverInfo, rtM);
  }

  rtsiSetSimTimeStep(&rtM->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&rtM->solverInfo, false);
  rtsiSetIsContModeFrozen(&rtM->solverInfo, false);
  rtM->intgData.f[0] = rtM->odeF[0];
  rtM->contStates = ((X *) &rtX);
  rtM->contStateDisabled = ((XDis *) &rtXDis);
  rtM->Timing.tStart = (0.0);
  rtsiSetSolverData(&rtM->solverInfo, (void *)&rtM->intgData);
  rtsiSetSolverName(&rtM->solverInfo,"ode1");
  rtmSetTPtr(rtM, &rtM->Timing.tArray[0]);
  rtM->Timing.stepSize0 = 0.1;

  /* InitializeConditions for Integrator: '<S44>/Integrator' */
  rtX.Integrator_CSTATE = 0.0;

  /* InitializeConditions for Integrator: '<S39>/Filter' */
  rtX.Filter_CSTATE = 0.0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
